﻿using CommonBase.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonBase.Validator
{
    public class IsbnValidator
    {
        public static bool CheckISBN10(string number)
        {
            number.CheckArgument(nameof(number));

            int mult = 1;
            int result = 0;

            for (int i = 0; i < number.Length - 1; i++)
            {
                result += Convert.ToInt32(number[i].ToString()) * mult;
                mult++;
            }

            result %= 11;

            if (result == 10 && number[number.Length - 1].ToString().ToLower() == "x")
            {
                return true;
            }
            else if (result == Convert.ToInt32(number[number.Length - 1].ToString()))
            {
                return true;
            }

            return false;
        }
    }
}
