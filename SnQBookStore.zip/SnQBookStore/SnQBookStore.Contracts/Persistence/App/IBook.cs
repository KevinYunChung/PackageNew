﻿using CommonBase.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnQBookStore.Contracts.Persistence.App
{
    public interface IBook : IVersionable, ICopyable<IBook>
    {
        DateTime CreateDate { get; set; }
        [ContractPropertyInfo(Required = true, MaxLength = 128)]
        string Author { get; set; }
        [ContractPropertyInfo(Required = true, MaxLength = 10, IsUnique = true)]
        string ISBNNumber { get; set; }
        [ContractPropertyInfo(Required = true, MaxLength = 1024)]
        string Description { get; set; }
        decimal Price { get; set; }
        [ContractPropertyInfo(Required = false, MaxLength = 1024)]
        string Note { get; set; }
    }
}
