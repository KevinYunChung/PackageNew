//@QnSBaseCode
//MdStart

namespace SnQBookStore.Transfer.Models
{
    public abstract partial class ModuleModel : TransferModel
    {
    }
}
//MdEnd
