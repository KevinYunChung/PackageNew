﻿using SnQBookStore.Logic.Entities.Persistence.App;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnQBookStore.Logic.Controllers.Persistence.App
{
    partial class BookController
    {
        protected override Book BeforeInsert(Book entity)
        {
            if (CommonBase.Validator.IsbnValidator.CheckISBN10(entity.ISBNNumber) == false)
            {
                throw new Modules.Exception.LogicException(Modules.Exception.ErrorType.InvalidEntityInsert);
            }
            return base.BeforeInsert(entity);
        }
        
        protected override Book BeforeUpdate(Book entity)
        {
            if (CommonBase.Validator.IsbnValidator.CheckISBN10(entity.ISBNNumber) == false)
            {
                throw new Modules.Exception.LogicException(Modules.Exception.ErrorType.InvalidEntityInsert);
            }
            return base.BeforeUpdate(entity);
        }
    }
}
