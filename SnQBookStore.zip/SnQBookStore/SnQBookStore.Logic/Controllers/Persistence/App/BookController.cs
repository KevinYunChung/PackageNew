//@GeneratedCode
namespace SnQBookStore.Logic.Controllers.Persistence.App
{
    sealed partial class BookController : GenericPersistenceController<SnQBookStore.Contracts.Persistence.App.IBook, Entities.Persistence.App.Book>
    {
        static BookController()
        {
            ClassConstructing();
            ClassConstructed();
        }
        static partial void ClassConstructing();
        static partial void ClassConstructed();
        internal BookController(DataContext.IContext context):base(context)
        {
            Constructing();
            Constructed();
        }
        partial void Constructing();
        partial void Constructed();
        internal BookController(ControllerObject controller):base(controller)
        {
            Constructing();
            Constructed();
        }
    }
}
