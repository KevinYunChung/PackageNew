//@CodeCopy
//MdStart
using SnQBookStore.Contracts;

namespace SnQBookStore.Logic.Entities
{
    internal abstract partial class IdentityEntity : EntityObject, IIdentifiable
	{
		public int Id { get; set; }
    }
}
//MdEnd
