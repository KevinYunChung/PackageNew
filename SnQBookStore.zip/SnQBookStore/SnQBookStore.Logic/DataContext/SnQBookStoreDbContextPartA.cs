//@GeneratedCode
namespace SnQBookStore.Logic.DataContext
{
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    partial class SnQBookStoreDbContext
    {
        protected DbSet<Entities.Persistence.App.Book> BookSet
        {
            get;
            set;
        }
        partial void GetDbSet<I, E>(ref DbSet<E> dbSet) where E : class
        {
            if (typeof(I) == typeof(SnQBookStore.Contracts.Persistence.App.IBook))
            {
                dbSet = BookSet as DbSet<E>;
            }
        }
        static partial void DoModelCreating(ModelBuilder modelBuilder)
        {
            var bookBuilder = modelBuilder.Entity<Entities.Persistence.App.Book>();
            bookBuilder.ToTable("Book", "App").HasKey("Id");
            modelBuilder.Entity<Entities.Persistence.App.Book>().Property(p => p.RowVersion).IsRowVersion();
            bookBuilder.Property(p => p.Author).IsRequired().HasMaxLength(128);
            bookBuilder.HasIndex(c => c.ISBNNumber).IsUnique();
            bookBuilder.Property(p => p.ISBNNumber).IsRequired().HasMaxLength(10);
            bookBuilder.Property(p => p.Description).IsRequired().HasMaxLength(1024);
            bookBuilder.Property(p => p.Note).HasMaxLength(1024);
            ConfigureEntityType(bookBuilder);
        }
        static partial void ConfigureEntityType(EntityTypeBuilder<Entities.Persistence.App.Book> entityTypeBuilder);
    }
}
