using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CommonBase.UnitTest
{
    [TestClass]
    public class NumberUnitTest
    {
        [TestMethod]
        public void Check_ValidNumber_WithLowerX_ResultTrue()
        {
            var number = "349913599x";

            Assert.IsTrue(CommonBase.Validator.IsbnValidator.CheckISBN10(number));
        }
        [TestMethod]
        public void Check_ValidNumber_WithUpperX_ResultTrue()
        {
            var number = "349913599X";

            Assert.IsTrue(CommonBase.Validator.IsbnValidator.CheckISBN10(number));
        }
        [TestMethod]
        public void Check_ValidNumber_WithWrongCheckNumber_ResultTrue()
        {
            var number = "3499135991";

            Assert.IsFalse(CommonBase.Validator.IsbnValidator.CheckISBN10(number));
        }
    }
}
