//@GeneratedCode
namespace SnQBookStore.AspMvc.Models.Persistence.App
{
    using System;
    public partial class Book : SnQBookStore.Contracts.Persistence.App.IBook
    {
        static Book()
        {
            ClassConstructing();
            ClassConstructed();
        }
        static partial void ClassConstructing();
        static partial void ClassConstructed();
        public Book()
        {
            Constructing();
            Constructed();
        }
        partial void Constructing();
        partial void Constructed();
        public System.DateTime CreateDate
        {
            get;
            set;
        }
        public System.String Author
        {
            get;
            set;
        }
        public System.String ISBNNumber
        {
            get;
            set;
        }
        public System.String Description
        {
            get;
            set;
        }
        public System.Decimal Price
        {
            get;
            set;
        }
        public System.String Note
        {
            get;
            set;
        }
        public void CopyProperties(SnQBookStore.Contracts.Persistence.App.IBook other)
        {
            if (other == null)
            {
                throw new System.ArgumentNullException(nameof(other));
            }
            bool handled = false;
            BeforeCopyProperties(other, ref handled);
            if (handled == false)
            {
                Id = other.Id;
                RowVersion = other.RowVersion;
                CreateDate = other.CreateDate;
                Author = other.Author;
                ISBNNumber = other.ISBNNumber;
                Description = other.Description;
                Price = other.Price;
                Note = other.Note;
            }
            AfterCopyProperties(other);
        }
        partial void BeforeCopyProperties(SnQBookStore.Contracts.Persistence.App.IBook other, ref bool handled);
        partial void AfterCopyProperties(SnQBookStore.Contracts.Persistence.App.IBook other);
        public static Persistence.App.Book Create()
        {
            BeforeCreate();
            var result = new Persistence.App.Book();
            AfterCreate(result);
            return result;
        }
        public static Persistence.App.Book Create(object other)
        {
            BeforeCreate(other);
            CommonBase.Extensions.ObjectExtensions.CheckArgument(other, nameof(other));
            var result = new Persistence.App.Book();
            CommonBase.Extensions.ObjectExtensions.CopyFrom(result, other);
            AfterCreate(result, other);
            return result;
        }
        public static Persistence.App.Book Create(SnQBookStore.Contracts.Persistence.App.IBook other)
        {
            BeforeCreate(other);
            var result = new Persistence.App.Book();
            result.CopyProperties(other);
            AfterCreate(result, other);
            return result;
        }
        static partial void BeforeCreate();
        static partial void AfterCreate(Persistence.App.Book instance);
        static partial void BeforeCreate(object other);
        static partial void AfterCreate(Persistence.App.Book instance, object other);
        static partial void BeforeCreate(SnQBookStore.Contracts.Persistence.App.IBook other);
        static partial void AfterCreate(Persistence.App.Book instance, SnQBookStore.Contracts.Persistence.App.IBook other);
    }
}
