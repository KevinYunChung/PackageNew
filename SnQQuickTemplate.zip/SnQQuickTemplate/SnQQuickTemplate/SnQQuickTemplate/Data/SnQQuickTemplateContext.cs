﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SnQQuickTemplate.Entities;

namespace SnQQuickTemplate.Data
{
    public class SnQQuickTemplateContext : DbContext
    {
        public SnQQuickTemplateContext (DbContextOptions<SnQQuickTemplateContext> options)
            : base(options)
        {
        }

        public DbSet<SnQQuickTemplate.Entities.Artist> Artist { get; set; }

        public DbSet<SnQQuickTemplate.Entities.Album> Album { get; set; }
    }
}
