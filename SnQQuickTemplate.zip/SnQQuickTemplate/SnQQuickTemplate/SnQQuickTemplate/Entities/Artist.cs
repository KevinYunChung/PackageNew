﻿namespace SnQQuickTemplate.Entities
{
    public class Artist : Identity
    {
        public string? Name { get; set; } = string.Empty;
    }
}
