﻿namespace SnQQuickTemplate.Entities
{
    public class Album : Identity
    {
        public int ArtistId { get; set; }
        public string? Name { get; set; } = string.Empty;
        public Artist? Artist { get; set; } = null;
    }
}
