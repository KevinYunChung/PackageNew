﻿using System.ComponentModel.DataAnnotations;

namespace SnQQuickTemplate.Entities
{
    public class Identity
    {
        [Key]
        public int Id { get; set; }
    }
}
