﻿using System.Diagnostics;
using SpaghettiMaker.Logic;

namespace SpaghettiMaker.ConApp
{
    class Program
    {
        static async Task Main()
        {
            await MakeAsyncBreakfast();
        }
        private static async Task MakeAsyncBreakfast()
        {
            Console.WriteLine("Make async Breakfast");
            Stopwatch sw = new Stopwatch();

            sw.Start();
            await Breakfast.MakeAsync();
            sw.Stop();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine($"It took {sw.ElapsedMilliseconds / 1000} seconds to prepare breakfast!");
        }
    }
}
