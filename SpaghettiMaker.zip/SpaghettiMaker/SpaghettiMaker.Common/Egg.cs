﻿namespace SpaghettiMaker.Common
{
    public class Egg
    {
        public bool Fried { get; set; }
    }
}
