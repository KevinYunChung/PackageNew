﻿namespace SpaghettiMaker.Common
{
    public class Toast
    {
        public bool HasToasted { get; set; }
        public bool HasButter { get; set; } 
        public bool HasJam { get; set; }
    }
}
