﻿namespace SpaghettiMaker.Common
{
    public class Pan
    {
        public bool Heated { get; set; }
        public bool InUse { get; set; }
    }
}
