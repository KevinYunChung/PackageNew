﻿using SpaghettiMaker.Common;

namespace SpaghettiMaker.Logic
{
    public class Breakfast
    {
        public static async Task MakeAsync()
        {
            var tasks = new List<Task>();

            tasks.Add(HeatPanAsync());
            tasks.Add(ToastBreadApplyButterAndJam());
            tasks.Add(HeatPansFryEggs());

            await Task.WhenAll(tasks);
        }
        public static async Task HeatPansFryEggs()
        {
            var panTask = HeatPanAsync();
            await Task.WhenAll(panTask);

            var eggsTask = FryEggsAsync(await panTask, 2);
            await Task.WhenAll(eggsTask);
        }
        public static async Task ToastBreadApplyButterAndJam()
        {
            int count = 2;

            await ToastBreadAsync(count);

            await ApplyButterAsync(count);
            await ApplyJamAsync(count);
        }
        public static async Task<Pan> HeatPanAsync()
        {
            Console.WriteLine();
            Console.Write("Heating pan");
            await Task.Delay(1000 * 10);
            Console.WriteLine();
            Console.Write("Pan is already");

            return new Pan()
            {
                Heated = true,
            };
        }
        public static async Task ToastBreadAsync(int count)
        {
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine();
                Console.Write("Toasting bread");
                await Task.Delay(1000 * 10);
            }
            Console.WriteLine();
            Console.Write("Breads are already");
        }
        public static async Task<IEnumerable<Egg>> FryEggsAsync(Pan pan, int count)
        {
            if (pan == null)
                throw new ArgumentNullException(nameof(pan));

            var result = new List<Egg>();

            if (pan.InUse == false)
            {
                pan.InUse = true;
                for (int i = 0; i < count; i++)
                {
                    Console.WriteLine();
                    Console.Write("Frying egg");
                    await Task.Delay(1000 * 10);

                    result.Add(new Egg() { Fried = true, });
                }
                pan.InUse = false;
            }
            Console.WriteLine();
            Console.Write("Eggs are already");
            return result;
        }
        public static async Task ApplyButterAsync(int count)
        {
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine();
                Console.Write("Brush bread with butter");
                await Task.Delay(1000 * 1);
            }

            Console.WriteLine();
            Console.Write("Breads have butter");
        }
        public static async Task ApplyJamAsync(int count)
        {
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine();
                Console.Write("Brush bread with jam");
                await Task.Delay(1000 * 1);
            }

            Console.WriteLine();
            Console.Write("Breads have jam");
        }
    }
}
