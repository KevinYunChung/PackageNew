﻿namespace BreakfastMaker.Common
{
	public class Juice : BreakfastDish
	{
	}
}
