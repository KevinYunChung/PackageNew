﻿namespace BreakfastMaker.Common
{
	public class Bacon : BreakfastDish
	{
		public bool Fryed { get; set; }
	}
}
