﻿namespace BreakfastMaker.Common
{
	public abstract class BreakfastDish
	{
	}
}
