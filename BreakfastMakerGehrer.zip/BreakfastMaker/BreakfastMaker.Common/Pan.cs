﻿namespace BreakfastMaker.Common
{
	public class Pan
	{
		public bool Heated { get; set; }
		public bool InUse { get; set; }
	}
}
