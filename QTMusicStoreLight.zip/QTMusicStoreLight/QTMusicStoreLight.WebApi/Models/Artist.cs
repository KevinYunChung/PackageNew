﻿namespace QTMusicStoreLight.WebApi.Models
{
    public class Artist : VersionModel
    {
        public string? Name { get; set; }
    }
}
