﻿namespace QTMusicStoreLight.WebApi.Models
{
    public class ArtistEdit
    {
        public string? Name { get; set; }
    }
}
