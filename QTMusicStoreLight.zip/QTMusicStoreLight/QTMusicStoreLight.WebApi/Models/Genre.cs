﻿namespace QTMusicStoreLight.WebApi.Models
{
    public class Genre : VersionModel
    {
        public string? Name { get; set; }
    }
}
