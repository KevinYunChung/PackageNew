﻿namespace QTMusicStoreLight.WebApi.Models
{
    public class GenreEdit
    {
        public string? Name { get; set; }
    }
}
