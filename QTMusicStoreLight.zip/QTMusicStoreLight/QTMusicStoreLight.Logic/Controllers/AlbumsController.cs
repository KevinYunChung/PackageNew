﻿namespace QTMusicStoreLight.Logic.Controllers
{
    public sealed class AlbumsController : GenericController<Entities.Album>
    {
        public AlbumsController() : base()
        {
        }

        public AlbumsController(ControllerObject other) : base(other)
        {
        }
    }
}
