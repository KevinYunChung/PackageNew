﻿namespace QTMusicStoreLight.Logic.Controllers
{
    public sealed class GenresController : GenericController<Entities.Genre>
    {
        public GenresController() : base()
        {
        }

        public GenresController(ControllerObject other) : base(other)
        {
        }
    }
}
